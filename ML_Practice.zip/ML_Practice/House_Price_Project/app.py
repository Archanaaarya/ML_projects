import streamlit as st
import numpy as np
import joblib

# Load model
model = joblib.load("house_model.pkl")

# Title
st.title("🏠 House Price Prediction")

st.write("Enter house details below")

# Inputs
area = st.number_input("Area (sq ft)", min_value=500)

bedrooms = st.slider("Bedrooms", 1, 10)

bathrooms = st.slider("Bathrooms", 1, 10)

stories = st.slider("Stories", 1, 5)

parking = st.slider("Parking", 0, 5)

# Prediction
if st.button("Predict Price"):

    input_data = np.array([[area, bedrooms, bathrooms, stories, parking]])

    prediction = model.predict(input_data)

    st.success(f"Estimated House Price: ₹ {prediction[0]:,.2f}")